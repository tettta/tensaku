# /home/esakit25/work/tensaku/src/tensaku/infer_pool.py
# -*- coding: utf-8 -*-
"""tensaku.infer_pool

@role
  - Train済みモデルで split（labeled/dev/test/pool 等）を推論し、preds_detail を作る。
  - (optional) logits/embeddings を round infer ディレクトリに保存する。

@design
  - Strict: out_dir は Layout にバインドされた ArtifactDir を要求する（台帳登録のため）。
  - 保存は必ず ArtifactFile.save_* 経由（= fs_core）で行い、レジャーと実体の齟齬を起こさない。
  - 同一パスへ繰り返し上書きする場合は、初回のみ record=True とし、以後は record=False（重複登録回避）。

@outputs (under out_dir)
  - preds_detail.csv           : 推論結果（全split concat）
  - infer.meta.json            : 推論メタ
  - *_logits.npy / *_embs.npy  : (optional) logits/embeddings
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Tuple

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from transformers import AutoModelForSequenceClassification, AutoTokenizer

from tensaku.data.base import create_adapter
from tensaku.experiments.fs_core import ArtifactDir
from tensaku.utils.strict_cfg import require_bool, require_int, require_mapping, require_str

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class InferOutputs:
    preds_detail: pd.DataFrame
    raw: Dict[str, Any]


def _require_artifact_dir(out_dir: Any) -> ArtifactDir:
    if not isinstance(out_dir, ArtifactDir):
        raise TypeError(
            "infer_core requires out_dir to be an ArtifactDir bound to Layout context. "
            "Pass e.g. layout.round_infer_dir(round=...) instead of a plain Path."
        )
    # context check
    if getattr(out_dir, "_context", None) is None:
        raise TypeError(
            "infer_core requires out_dir to be an ArtifactDir bound to Layout context. "
            "(detached ArtifactDir: missing _context)"
        )
    return out_dir


def _save_df_csv(file: Any, df: pd.DataFrame, *, kind: str, record: bool) -> None:
    header = list(df.columns)
    rows = df.itertuples(index=False, name=None)
    file.save_csv(rows=rows, header=header, kind=kind, record=record)


def infer_core(
    *,
    split: str,
    out_dir: ArtifactDir,
    cfg: Mapping[str, Any],
) -> Tuple[Dict[str, Any], pd.DataFrame, Dict[str, Any]]:
    """Run inference for one split.

    Args:
      split: split name (labeled/dev/test/pool)
      out_dir: Layout-bound ArtifactDir
      cfg: full cfg mapping

    Returns:
      (rc_meta, detail_df, raw)
    """
    out_dir = _require_artifact_dir(out_dir)
    out_dir.ensure()

    # --- config ---
    data_cfg = require_mapping(cfg, "data")
    run_cfg = require_mapping(cfg, "run")
    model_cfg = require_mapping(cfg, "model")
    infer_cfg = require_mapping(cfg, "infer")

    data_dir = Path(require_str(run_cfg, "data_dir"))
    device = "cuda" if torch.cuda.is_available() else "cpu"

    model_name = require_str(model_cfg, "name")
    num_labels = require_int(model_cfg, "num_labels")

    max_len = require_int(infer_cfg, "max_len")
    batch_size = require_int(infer_cfg, "batch_size")
    save_logits = require_bool(infer_cfg, "save_logits")

    # --- dataset adapter ---
    adapter = create_adapter(data_dir=data_dir, cfg=cfg)
    ds = adapter.load_split(split=split)

    tok = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=num_labels)

    # ckpt
    # prefer task to place best checkpoint at layout.round_ckpt_dir(...).best
    # but here keep it simple: cfg.model.ckpt_path required
    ckpt_path_s = require_str(model_cfg, "ckpt_path")
    ckpt_path = Path(ckpt_path_s)
    if not ckpt_path.exists():
        raise FileNotFoundError(f"ckpt not found: {ckpt_path}")
    state = torch.load(ckpt_path, map_location="cpu")
    if isinstance(state, dict) and "model" in state and isinstance(state["model"], dict):
        state = state["model"]
    if not isinstance(state, dict):
        raise TypeError(f"Unsupported checkpoint format: {type(state).__name__}")
    missing, unexpected = model.load_state_dict(state, strict=False)
    if missing:
        logger.warning("[infer] missing keys: %s", missing[:10])
    if unexpected:
        logger.warning("[infer] unexpected keys: %s", unexpected[:10])

    model.to(device)
    model.eval()

    def collate(batch: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        texts = [b["text"] for b in batch]
        enc = tok(texts, truncation=True, padding=True, max_length=max_len, return_tensors="pt")
        y = torch.tensor([int(b["score"]) for b in batch], dtype=torch.long)
        enc["labels"] = y
        return enc

    loader = DataLoader(ds, batch_size=batch_size, shuffle=False, collate_fn=collate)

    all_ids: List[Any] = []
    all_y: List[int] = []
    all_pred: List[int] = []
    all_conf: List[float] = []
    all_logits: List[np.ndarray] = []
    all_embs: List[np.ndarray] = []

    with torch.no_grad():
        for batch in loader:
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["labels"].to(device)

            out = model(input_ids=input_ids, attention_mask=attention_mask, output_hidden_states=True)
            logits = out.logits
            probs = torch.softmax(logits, dim=-1)
            pred = torch.argmax(probs, dim=-1)
            conf = torch.max(probs, dim=-1).values

            # embeddings: CLS of last hidden state
            hs = out.hidden_states[-1]
            cls = hs[:, 0, :]

            # ids
            # adapter returns dicts; dataset should include id
            # DataLoader collate doesn't include id; pull from underlying dataset by index
            # simplest: ds items include id; DataLoader can't. So collect later via adapter API.
            # Strict: adapter must provide ids in batch; if not, error.
            # (We assume ds yields dict with id and was preserved by DataLoader default; but collate strips.)
            # Workaround: adapter dataset provides internal 'id' list via attribute.
            if not hasattr(ds, "ids"):
                raise RuntimeError("Dataset must expose 'ids' attribute for infer (Strict).")

            # current batch indices tracking
            # We cannot recover indices from collate; use ds.__iter__? Not available.
            # Instead, rely on DataLoader with dataset returning dict including id and let default collate.
            # Strict: to avoid silent mismatch, we enforce dataset element includes 'id' and we don't override.
            raise RuntimeError(
                "infer_core requires dataset to yield dicts including 'id' and uses default collate. "
                "Current implementation overrides collate, which drops 'id'. "
                "Please use infer_pool_core (below) which preserves ids correctly."
            )

    # unreachable


# --------------------------------------------------------------------------------------
# Public entry: infer_pool_core (keeps existing behavior; only changes IO to fs_core)
# --------------------------------------------------------------------------------------

def infer_pool_core(
    *,
    split: str,
    out_dir: ArtifactDir,
    cfg: Mapping[str, Any],
) -> Tuple[Dict[str, Any], pd.DataFrame, Dict[str, Any]]:
    """Infer for a given split and write artifacts under out_dir.

    This function is used by tasks.standard. It keeps the data/adapter behavior
    already used in the project, but enforces fs_core saving.
    """
    out_dir = _require_artifact_dir(out_dir)
    out_dir.ensure()

    data_cfg = require_mapping(cfg, "data")
    run_cfg = require_mapping(cfg, "run")
    model_cfg = require_mapping(cfg, "model")
    infer_cfg = require_mapping(cfg, "infer")

    data_dir = Path(require_str(run_cfg, "data_dir"))
    device = "cuda" if torch.cuda.is_available() else "cpu"

    model_name = require_str(model_cfg, "name")
    num_labels = require_int(model_cfg, "num_labels")

    max_len = require_int(infer_cfg, "max_len")
    batch_size = require_int(infer_cfg, "batch_size")
    save_logits = require_bool(infer_cfg, "save_logits")

    adapter = create_adapter(data_dir=data_dir, cfg=cfg)
    ds = adapter.load_split(split=split)

    tok = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=num_labels)

    ckpt_path_s = require_str(model_cfg, "ckpt_path")
    ckpt_path = Path(ckpt_path_s)
    if not ckpt_path.exists():
        raise FileNotFoundError(f"ckpt not found: {ckpt_path}")
    state = torch.load(ckpt_path, map_location="cpu")
    if isinstance(state, dict) and "model" in state and isinstance(state["model"], dict):
        state = state["model"]
    if not isinstance(state, dict):
        raise TypeError(f"Unsupported checkpoint format: {type(state).__name__}")
    model.load_state_dict(state, strict=False)

    model.to(device)
    model.eval()

    # Dataset must yield dict with keys: id,text,score
    def collate(batch: List[Dict[str, Any]]) -> Dict[str, Any]:
        ids = [b["id"] for b in batch]
        texts = [b["text"] for b in batch]
        labels = torch.tensor([int(b["score"]) for b in batch], dtype=torch.long)
        enc = tok(texts, truncation=True, padding=True, max_length=max_len, return_tensors="pt")
        return {"id": ids, "labels": labels, **enc}

    loader = DataLoader(ds, batch_size=batch_size, shuffle=False, collate_fn=collate)

    all_ids: List[Any] = []
    all_y: List[int] = []
    all_pred: List[int] = []
    all_conf: List[float] = []

    # raw arrays
    logits_list: List[np.ndarray] = []
    embs_list: List[np.ndarray] = []

    with torch.no_grad():
        for batch in loader:
            ids = batch["id"]
            labels = batch["labels"].to(device)
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)

            out = model(input_ids=input_ids, attention_mask=attention_mask, output_hidden_states=True)
            logits = out.logits
            probs = torch.softmax(logits, dim=-1)
            pred = torch.argmax(probs, dim=-1)
            conf = torch.max(probs, dim=-1).values

            # CLS embeddings
            hs = out.hidden_states[-1]
            cls = hs[:, 0, :]

            all_ids.extend(ids)
            all_y.extend(labels.detach().cpu().numpy().tolist())
            all_pred.extend(pred.detach().cpu().numpy().tolist())
            all_conf.extend(conf.detach().cpu().numpy().tolist())

            if save_logits:
                logits_list.append(logits.detach().cpu().numpy())
                embs_list.append(cls.detach().cpu().numpy())

    df = pd.DataFrame(
        {
            "id": all_ids,
            "split": [split] * len(all_ids),
            "y_true": all_y,
            "y_pred": all_pred,
            "conf_msp": all_conf,
        }
    )

    raw: Dict[str, Any] = {}
    if save_logits:
        raw["logits"] = np.concatenate(logits_list, axis=0) if logits_list else np.zeros((0, num_labels), dtype=np.float32)
        raw["embs"] = np.concatenate(embs_list, axis=0) if embs_list else np.zeros((0, 768), dtype=np.float32)

        f_logits = out_dir / f"{split}_logits.npy"
        f_embs = out_dir / f"{split}_embs.npy"

        f_logits.save_npy(
            raw["logits"],
            record=not f_logits.exists(),
            kind="npy",
            meta={"what": "logits", "split": split},
        )
        f_embs.save_npy(
            raw["embs"],
            record=not f_embs.exists(),
            kind="npy",
            meta={"what": "embs", "split": split},
        )

    # preds_detail.csv
    f_pred = out_dir / "preds_detail.csv"
    _save_df_csv(f_pred, df, kind="pred", record=not f_pred.exists())

    meta = {
        "split": split,
        "n": int(len(df)),
        "save_logits": bool(save_logits),
        "model": model_name,
        "num_labels": int(num_labels),
    }
    f_meta = out_dir / "infer.meta.json"
    f_meta.save_json(meta, record=not f_meta.exists(), kind="meta")

    rc = {"ok": True, "n": int(len(df))}
    return rc, df, raw
