# /home/esakit25/work/tensaku/src/tensaku/pipelines/al.py
# -*- coding: utf-8 -*-
"""Active Learning experiment runner.

Design intent
- Pipeline is a *thin orchestrator*: call lower modules, pass data, persist artifacts.
- No silent fallbacks: if required artifacts are missing, fail fast.
- Persist "analysis essentials" for viz/research:
  - metrics/al_learning_curve.csv
  - metrics/al_history.csv
  - metrics/hitl_summary_rounds.csv
  - metrics/hitl_summary_final.csv
  - selection/al_samples_round_XXX.csv
  - selection/al_samples_all.csv
  - predictions/final/{preds_detail.csv,gate_assign.csv} copied from the last round

Notes
- Some metrics values are non-scalar (list/dict). They are JSON-encoded in CSV.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
from dataclasses import replace
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import pandas as pd

from tensaku.al.loop import run_one_step
from tensaku.al.state import ALState
from tensaku.data.base import create_adapter
from tensaku.experiments.layout import ExperimentLayout
from tensaku.tasks.factory import create_task_patched

LOGGER = logging.getLogger(__name__)


def _jsonify(v: Any) -> Any:
    if v is None:
        return ""
    if isinstance(v, (str, int, float, bool)):
        return v
    try:
        return json.dumps(v, ensure_ascii=False, sort_keys=True)
    except Exception:
        return str(v)


def _stable_header(rows: Sequence[Mapping[str, Any]], base: Sequence[str]) -> List[str]:
    keys = set()
    for r in rows:
        keys.update(r.keys())
    ordered = list(base)
    for k in sorted(keys):
        if k not in ordered:
            ordered.append(k)
    return ordered


def _save_dict_rows_csv(layout: ExperimentLayout, path: Path, rows: Sequence[Mapping[str, Any]], base_cols: Sequence[str]) -> None:
    header = _stable_header(rows, base_cols)
    out_rows: List[List[Any]] = []
    for r in rows:
        out_rows.append([_jsonify(r.get(h, "")) for h in header])
    layout.save_csv(path, rows=out_rows, header=list(header), record=True)


def _extract_gate_rows(metrics: Mapping[str, Any], round_index: int, n_labeled: int, n_pool: int) -> List[Dict[str, Any]]:
    # metrics keys are like:
    # gate.<conf_key>.tau, gate.<conf_key>.dev.coverage, gate.<conf_key>.test.qwk, ...
    gate_prefix = "gate."
    conf_keys = set()
    for k in metrics.keys():
        if k.startswith(gate_prefix):
            parts = k.split(".")
            if len(parts) >= 3:
                conf_keys.add(parts[1])
    rows: List[Dict[str, Any]] = []
    for ck in sorted(conf_keys):
        base = {
            "round": round_index,
            "n_labeled": n_labeled,
            "n_pool": n_pool,
            "conf_key": ck,
        }
        prefix = f"gate.{ck}."
        for k, v in metrics.items():
            if k.startswith(prefix):
                base[k[len(prefix):]] = v
        rows.append(base)
    return rows


def _require_file(path: Path, what: str) -> None:
    if not path.exists():
        raise FileNotFoundError(f"Required artifact missing: {what}: {path}")


def _copy_and_record(layout: ExperimentLayout, src: Path, dst: Path) -> None:
    _require_file(src, "source")
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    layout.record_artifact(dst, kind="file", note=f"copied_from={src.name}")


def run_experiment(cfg: Mapping[str, Any]) -> int:
    """Run one AL experiment.

    Args:
        cfg: plain mapping (OmegaConf resolved container).

    Returns:
        exit code (0=success)
    """
    layout = ExperimentLayout.from_cfg(cfg)

    # Ensure required dirs exist
    layout.prepare_dirs()

    # Create adapter and initial split (strict behavior is inside lower modules)
    adapter = create_adapter(cfg)
    split0 = adapter.make_initial_split()

    task = create_task_patched(cfg=cfg, adapter=adapter, layout=layout, initial_split=split0)

    # AL state
    state = ALState(
        labeled_ids=set(split0.labeled_ids),
        pool_ids=set(split0.pool_ids),
        round_index=0,
    )

    # experiment-level accumulators
    al_history_rows: List[Dict[str, Any]] = []
    al_learning_curve_rows: List[Dict[str, Any]] = []
    hitl_summary_rows: List[Dict[str, Any]] = []
    samples_all_rows: List[Dict[str, Any]] = []

    sampler_name = str(cfg.get("al", {}).get("sampler", ""))
    budget = int(cfg.get("al", {}).get("budget", 0))

    # Main loop
    max_rounds = int(cfg.get("al", {}).get("n_rounds", 0))
    if max_rounds <= 0:
        raise ValueError("al.n_rounds must be > 0 (Strict)")

    last_round_executed: Optional[int] = None

    for _ in range(max_rounds):
        r = state.round_index
        n_labeled = len(state.labeled_ids)
        n_pool = len(state.pool_ids)

        LOGGER.info("[AL] round=%d n_labeled=%d n_pool=%d", r, n_labeled, n_pool)

        new_state, selected_ids, out = run_one_step(
            state=state,
            task=task,
            sampler=task.sampler,
            budget=budget,
        )

        # Persist per-round selection (strict: selected_ids must be a list)
        if selected_ids is None:
            raise RuntimeError("selected_ids is None (Strict)")

        # selection round rows
        scores = out.pool_scores
        # rank is selection order
        round_rows: List[Dict[str, Any]] = []
        for rank, sid in enumerate(selected_ids):
            sc = float(scores.get(sid, float("nan"))) if hasattr(scores, "get") else float("nan")
            row = {
                "round": r,
                "id": sid,
                "split": "pool",
                "al_rank": rank,
                "score": sc,
                "sampler": sampler_name,
                "budget": budget,
                "n_labeled_before": n_labeled,
                "n_pool_before": n_pool,
            }
            round_rows.append(row)
            samples_all_rows.append(row)

        _save_dict_rows_csv(
            layout,
            layout.selection_al_samples_round(round=r),
            round_rows,
            base_cols=["round", "id", "split", "al_rank", "score", "sampler", "budget", "n_labeled_before", "n_pool_before"],
        )
        _save_dict_rows_csv(
            layout,
            layout.selection_al_samples_all,
            samples_all_rows,
            base_cols=["round", "id", "split", "al_rank", "score", "sampler", "budget", "n_labeled_before", "n_pool_before"],
        )

        # learning curve rows
        coverage = float(len(selected_ids)) / float(n_pool) if n_pool > 0 else 0.0
        al_history_rows.append(
            {
                "round": r,
                "n_labeled": n_labeled,
                "n_pool": n_pool,
                "added": len(selected_ids),
                "coverage": coverage,
            }
        )
        _save_dict_rows_csv(
            layout,
            layout.metrics_al_history,
            al_history_rows,
            base_cols=["round", "n_labeled", "n_pool", "added", "coverage"],
        )

        metrics = out.metrics if isinstance(out.metrics, Mapping) else {}
        lc_row: Dict[str, Any] = {
            "round": r,
            "n_labeled": n_labeled,
            "n_pool": n_pool,
            "added": len(selected_ids),
            "coverage": coverage,
        }
        for k, v in metrics.items():
            lc_row[k] = v
        al_learning_curve_rows.append(lc_row)
        _save_dict_rows_csv(
            layout,
            layout.metrics_al_learning_curve,
            al_learning_curve_rows,
            base_cols=["round", "n_labeled", "n_pool", "added", "coverage"],
        )

        # HITL summaries (long format)
        gate_rows = _extract_gate_rows(metrics, round_index=r, n_labeled=n_labeled, n_pool=n_pool)
        hitl_summary_rows.extend(gate_rows)
        _save_dict_rows_csv(
            layout,
            layout.metrics_hitl_summary_rounds,
            hitl_summary_rows,
            base_cols=["round", "n_labeled", "n_pool", "conf_key"],
        )

        # prepare next round
        state = new_state
        last_round_executed = r

        # stop if no more pool or no selection
        if len(selected_ids) == 0 or len(state.pool_ids) == 0:
            LOGGER.info("[AL] stopping: selected=0 or pool empty")
            break

    if last_round_executed is None:
        raise RuntimeError("AL finished without executing any round (Strict)")

    # Finalize: copy last round predictions to final
    last_r = last_round_executed
    _copy_and_record(layout, layout.predictions_round_detail(round=last_r), layout.predictions_final_detail)
    _copy_and_record(layout, layout.predictions_round_gate_assign(round=last_r), layout.predictions_final_gate_assign)

    # HITL final summary is last round subset
    final_gate = [r for r in hitl_summary_rows if int(r.get("round", -1)) == int(last_r)]
    if not final_gate:
        raise RuntimeError("No gate summary rows for last round (Strict)")
    _save_dict_rows_csv(
        layout,
        layout.metrics_hitl_summary_final,
        final_gate,
        base_cols=["round", "n_labeled", "n_pool", "conf_key"],
    )

    LOGGER.info("[AL] experiment finished. last_round=%d", last_r)
    return 0
